<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied</title>
</head>
<style>
    .center {
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        margin: auto;
        position: absolute;
        top: 0;
        left: 0;
        bottom: 230px;
        right: 0;
    }
</style>

<body>
    <h2 class="center">Account is Inactive</h2>
</body>

</html>