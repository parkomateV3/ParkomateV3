@extends('header')
@section('content')

<div class="container">
    <h2>Home</h2>
</div>

@endsection