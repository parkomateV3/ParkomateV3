<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
    }

    #chartdiv {
        width: 100%;
        height: 500px;
        max-width: 100%;
    }
</style>

<body>
    <div id="chartdiv"></div>



    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>



    <!-- <script>
        /**
         * ---------------------------------------
         * This demo was created using amCharts 5.
         * 
         * For more information visit:
         * https://www.amcharts.com/
         * 
         * Documentation is available at:
         * https://www.amcharts.com/docs/v5/
         * ---------------------------------------
         */


        // Create root element
        // https://www.amcharts.com/docs/v5/getting-started/#Root_element
        var root = am5.Root.new("chartdiv");


        // Set themes
        // https://www.amcharts.com/docs/v5/concepts/themes/
        root.setThemes([
            am5themes_Animated.new(root)
        ]);


        // Generate random data
        var value = 100;

        function generateChartData() {
            var chartData = [];
            var firstDate = new Date();
            firstDate.setMinutes(firstDate.getMinutes() - 50); // Go back 50 minutes
            firstDate.setSeconds(0, 0);

            for (var i = 0; i < 50; i++) {
                var newDate = new Date(firstDate);
                newDate.setMinutes(newDate.getMinutes() + i);

                value += (Math.random() < 0.5 ? 1 : -1) * Math.random() * 10;

                chartData.push({
                    date: newDate.getTime(),
                    value: value
                });
            }
            return chartData;
        }

        var data = generateChartData();


        // Create chart
        // https://www.amcharts.com/docs/v5/charts/xy-chart/
        var chart = root.container.children.push(am5xy.XYChart.new(root, {
            focusable: true,
            panX: true,
            panY: true,
            wheelX: "panX",
            wheelY: "zoomX",
            pinchZoomX: true,
            paddingLeft: 0
        }));

        var easing = am5.ease.linear;


        // Create axes
        // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
        var xAxis = chart.xAxes.push(am5xy.DateAxis.new(root, {
            maxDeviation: 0.5,
            groupData: false,
            extraMax: 0.1, // this adds some space in front
            extraMin: -0.1, // this removes some space form th beginning so that the line would not be cut off
            baseInterval: {
                timeUnit: "minute",
                count: 1
            },
            renderer: am5xy.AxisRendererX.new(root, {
                minorGridEnabled: true,
                minGridDistance: 50
            }),
            tooltip: am5.Tooltip.new(root, {})
        }));

        var yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
            renderer: am5xy.AxisRendererY.new(root, {})
        }));


        // Add series
        // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
        var series = chart.series.push(am5xy.LineSeries.new(root, {
            name: "Series 1",
            xAxis: xAxis,
            yAxis: yAxis,
            valueYField: "value",
            valueXField: "date",
            tooltip: am5.Tooltip.new(root, {
                pointerOrientation: "horizontal",
                labelText: "{valueY}"
            })
        }));

        // tell that the last data item must create bullet
        data[data.length - 1].bullet = true;
        series.data.setAll(data);


        // Create animating bullet by adding two circles in a bullet container and
        // animating radius and opacity of one of them.
        series.bullets.push(function(root, series, dataItem) {
            // only create sprite if bullet == true in data context
            if (dataItem.dataContext.bullet) {
                var container = am5.Container.new(root, {});
                var circle0 = container.children.push(am5.Circle.new(root, {
                    radius: 5,
                    fill: am5.color(0xff0000)
                }));
                var circle1 = container.children.push(am5.Circle.new(root, {
                    radius: 5,
                    fill: am5.color(0xff0000)
                }));

                circle1.animate({
                    key: "radius",
                    to: 20,
                    duration: 1000,
                    easing: am5.ease.out(am5.ease.cubic),
                    loops: Infinity
                });
                circle1.animate({
                    key: "opacity",
                    to: 0,
                    from: 1,
                    duration: 1000,
                    easing: am5.ease.out(am5.ease.cubic),
                    loops: Infinity
                });

                return am5.Bullet.new(root, {
                    locationX: undefined,
                    sprite: container
                })
            }
        })


        // Add cursor
        // https://www.amcharts.com/docs/v5/charts/xy-chart/cursor/
        var cursor = chart.set("cursor", am5xy.XYCursor.new(root, {
            xAxis: xAxis
        }));
        cursor.lineY.set("visible", false);


        // Update data every second
        setInterval(function() {
            addData();
        }, 5000)


        function addData() {
            var lastDataItem = series.dataItems[series.dataItems.length - 1];

            var lastValue = lastDataItem.get("valueY");
            var newValue = value + ((Math.random() < 0.5 ? 1 : -1) * Math.random() * 5);
            var lastDate = new Date(lastDataItem.get("valueX"));
            // var time = am5.time.add(new Date(lastDate), "second", 1).getTime();
            var time = new Date().getTime();
            series.data.removeIndex(0);
            series.data.push({
                date: time,
                value: newValue
            })

            var newDataItem = series.dataItems[series.dataItems.length - 1];
            newDataItem.animate({
                key: "valueYWorking",
                to: newValue,
                from: lastValue,
                duration: 600,
                easing: easing
            });

            // use the bullet of last data item so that a new sprite is not created
            newDataItem.bullets = [];
            newDataItem.bullets[0] = lastDataItem.bullets[0];
            newDataItem.bullets[0].get("sprite").dataItem = newDataItem;
            // reset bullets
            lastDataItem.dataContext.bullet = false;
            lastDataItem.bullets = [];


            var animation = newDataItem.animate({
                key: "locationX",
                to: 0.5,
                from: -0.5,
                duration: 600
            });
            if (animation) {
                var tooltip = xAxis.get("tooltip");
                if (tooltip && !tooltip.isHidden()) {
                    animation.events.on("stopped", function() {
                        xAxis.updateTooltip();
                    })
                }
            }
        }


        // Make stuff animate on load
        // https://www.amcharts.com/docs/v5/concepts/animations/
        chart.appear(1000, 100);
    </script> -->
    <script>
        // var data = [22, 34, 2, 4, 2, 11, 3, 42, 21, 24, 3, 52, 45, 5, 24, 5, 23, 5, 3, 43, 2, 21, 23, 5, 2, 1, 11, 3, 5, 6, 6, 3, 34, 5, 43, 45, 1, 2, 33, 5, 33, 42, 2, 45, 5, 2, 1, 12, 3, 44, 3, 43, 2, 45, 2, 33, 2, 5, 2, 3, 5, 2, 3, 4, 5, 66, 22, 33, 44, 55, 32, 21, 1, 33, 44, 5, 21, 3, 52, 22, 52, 34];

        // function generateChartData() {
        //     var chartData = [];
        //     var currentDate = new Date();
        //     currentDate.setMinutes(currentDate.getMinutes() - 50); // Start 50 minutes ago
        //     currentDate.setSeconds(0, 0);

        //     var value = 100; // Starting value for the chart
        //     for (var i = 0; i < 50; i++) {
        //         var newDate = new Date(currentDate);
        //         newDate.setMinutes(currentDate.getMinutes() + i); // Increment time by 1 minute

        //         value += (Math.random() < 0.5 ? 1 : -1) * Math.random() * 10; // Randomize value

        //         chartData.push({
        //             date: newDate.getTime(), // Convert date to timestamp
        //             value: value
        //         });
        //     }
        //     return chartData;
        // }

        // Example data output
        var data = @json($data);
        // console.log(data);

        var last_hour_data_chart_root = am5.Root.new("chartdiv");

        last_hour_data_chart_root.setThemes([
            am5themes_Animated.new(last_hour_data_chart_root)
        ]);

        last_hour_data_chart_root.dateFormatter.setAll({
            dateFormat: "dd MMM, yyyy hh:mm a",
            dateFields: ["valueX"]
        });

        var easing = am5.ease.linear;

        window.last_hour_data_chart = last_hour_data_chart_root.container.children.push(am5xy.XYChart.new(last_hour_data_chart_root, {
            focusable: false,
            panX: true, // Disable panning on X-axis
            panY: false, // Disable panning on Y-axis
            wheelX: "none", // Disable zooming on X-axis
            wheelY: "none", // Disable zooming on Y-axis
            pinchZoomX: false, // Disable pinch zoom on X-axis
            pinchZoomY: false // Disable pinch zoom on Y-axis

            // panX: true,
            // panY: true,
            // wheelX: "panX",
            // wheelY: "zoomX",
            // pinchZoomX: true
        }));

        var xAxis = window.last_hour_data_chart.xAxes.push(am5xy.DateAxis.new(last_hour_data_chart_root, {
            maxDeviation: 0.5,
            groupData: false,
            extraMax: 0.1, // this adds some space in front
            extraMin: -0.1, // this removes some space form th beginning so that the line would not be cut off
            baseInterval: {
                timeUnit: "minute",
                count: 1
            },
            renderer: am5xy.AxisRendererX.new(last_hour_data_chart_root, {
                minGridDistance: 50
            }),
            tooltip: am5.Tooltip.new(last_hour_data_chart_root, {})
        }));

        var yAxis = window.last_hour_data_chart.yAxes.push(am5xy.ValueAxis.new(last_hour_data_chart_root, {
            renderer: am5xy.AxisRendererY.new(last_hour_data_chart_root, {})
        }));

        var series = window.last_hour_data_chart.series.push(am5xy.LineSeries.new(last_hour_data_chart_root, {
            name: "Occupancy",
            xAxis: xAxis,
            yAxis: yAxis,
            valueYField: "value",
            valueXField: "date",
            tooltip: am5.Tooltip.new(last_hour_data_chart_root, {
                pointerOrientation: "horizontal",
                labelText: "{valueY}"
            })
        }));

        if (data.length > 0) {
            data[data.length - 1].bullet = true;
        }
        series.data.setAll(data);
        // Create animating bullet by adding two circles in a bullet container and
        // animating radius and opacity of one of them.
        series.bullets.push(function(last_hour_data_chart_root, series, dataItem) {
            // only create sprite if bullet == true in data context
            if (dataItem.dataContext.bullet) {
                var container = am5.Container.new(last_hour_data_chart_root, {});
                var circle0 = container.children.push(am5.Circle.new(last_hour_data_chart_root, {
                    radius: 5,
                    fill: am5.color(0xff0000)
                }));
                var circle1 = container.children.push(am5.Circle.new(last_hour_data_chart_root, {
                    radius: 5,
                    fill: am5.color(0xff0000)
                }));

                circle1.animate({
                    key: "radius",
                    to: 20,
                    duration: 1000,
                    easing: am5.ease.out(am5.ease.cubic),
                    loops: Infinity
                });
                circle1.animate({
                    key: "opacity",
                    to: 0,
                    from: 1,
                    duration: 1000,
                    easing: am5.ease.out(am5.ease.cubic),
                    loops: Infinity
                });

                return am5.Bullet.new(last_hour_data_chart_root, {
                    locationX: undefined,
                    sprite: container
                })
            }
        });

        // Add cursor
        // https://www.amcharts.com/docs/v5/charts/xy-chart/cursor/
        var cursor = window.last_hour_data_chart.set("cursor", am5xy.XYCursor.new(last_hour_data_chart_root, {
            xAxis: xAxis
        }));
        cursor.lineY.set("visible", false);
        window.last_hour_data_chart.appear(1000, 100);
        setInterval(function() {
            appendLast4HourGraphInitialData();
        }, 60000);
    </script>
</body>

</html>