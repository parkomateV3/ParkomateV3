<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alert mail</title>
</head>

<body style="font-family: Arial, sans-serif; color: #000000;">
    <h3><?php echo e($mailData['subject']); ?></h3>
    <p>
        <?php if($mailData['device'] == 'sensor'): ?>
        <strong>Site Name:</strong> <?php echo e($mailData['site_name']); ?><br>
        <strong>Floor Name:</strong> <?php echo e($mailData['floor_name']); ?><br>
        <strong>Zonal Name:</strong> <?php echo e($mailData['zonal_name']); ?><br>
        <strong>Sensor Name:</strong> <?php echo e($mailData['sensor_name']); ?><br>
        <strong>Sensor Unique No:</strong> <?php echo e($mailData['sensor_unique_no']); ?><br>
        <strong>Status:</strong> <?php echo e($mailData['status']); ?><br>
        <strong>Date:</strong> <?php echo e($mailData['date']); ?>

        <?php elseif($mailData['device'] == 'display'): ?>
        <strong>Display Unique No:</strong> <?php echo e($mailData['sensor_id']); ?><br>
        <strong>Message:</strong> Unregistered device is communicating with server.<br>
        <?php elseif($mailData['device'] == 'displayapi'): ?>
        <strong>Display Unique No:</strong> <?php echo e($mailData['sensor_id']); ?><br>
        <strong>Message:</strong> This display api not calling more than 15 minutes.<br>
        <?php elseif($mailData['device'] == 'site_error'): ?>
        <strong>Site Name:</strong> <?php echo e($mailData['site_name']); ?><br>
        <strong>Message:</strong> The site is offline.<br>
        <?php elseif($mailData['device'] == 'deviceerror'): ?>
        <strong>Device Unique No:</strong> <?php echo e($mailData['sensor_id']); ?><br>
        <strong>Message:</strong> Unregistered device is communicating with server.<br>
        <?php else: ?>
        <strong>Zonal Unique No:</strong> <?php echo e($mailData['sensor_id']); ?><br>
        <strong>Message:</strong> Unregistered device is communicating with server.<br>
        <?php endif; ?>
    </p>
</body>

</html><?php /**PATH F:\Laravel\parkomate\resources\views/emails/sensorMail.blade.php ENDPATH**/ ?>