
<?php $__env->startSection('content'); ?>
<style>
    /* Style for the dropdown */
    .multiselect-dropdown {
        width: 100%;
        position: relative;
    }

    /* Search box inside the dropdown */
    .search-box,
    .search-box-no {
        width: 100%;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 5px
    }

    /* Style the dropdown items */
    .dropdown-list,
    .dropdown-list-no {
        border: 1px solid #ccc;
        max-height: 150px;
        overflow-y: auto;
        display: none;
        position: absolute;
        width: 100%;
        background-color: white;
        z-index: 999;
    }

    .dropdown-list label {
        display: block;
        padding: 5px;
        cursor: pointer;
    }

    .dropdown-list-no label {
        display: block;
        padding: 5px;
        cursor: pointer;
    }

    .dropdown-list label:hover {
        background-color: #f0f0f0;
    }

    .dropdown-list-no label:hover {
        background-color: #f0f0f0;
    }

    .dropdown-list input {
        margin-right: 5px;
    }

    .dropdown-list-no input {
        margin-right: 5px;
    }

    .dropdown-list.active {
        display: block;
    }

    .dropdown-list-no.active {
        display: block;
    }

    label {
        margin: 0 !important;
    }
</style>
<div class="container">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-6 m-auto">
            <h4 class="text-center">Display Data Update</h4>
            <form action="<?php echo e(route('displaydata.update', $editDisplay->data_id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="modal-body">
                    <div class="mb-3" style="pointer-events: none;">
                        <label for="display_id" class="form-label">Display</label>
                        <input type="text" name="display_id" class="form-control" id="display_id" value="<?php echo e($editDisplay->display_id); ?> (<?php echo e(getSitename($editDisplay->site_id)); ?>)">
                        <input type="hidden" name="site_id" value="<?php echo e($editDisplay->site_id); ?>">
                    </div>
                    <div class="mb-2 multiselect-dropdown">
                        <input type="text" placeholder="Search..." class="search-box form-control" onclick="toggleDropdown()" onkeyup="filterOptions()">
                        <div class="dropdown-list" id="dropdown-list">
                            <label><b>Floors</b></label>
                            <?php $__currentLoopData = $floorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($floor->floor_name, $floors)): ?>
                            <label><input type="checkbox" class="check <?php echo e($floor->floor_id); ?>" id="floor" value="<?php echo e($floor->floor_name); ?>" checked><?php echo e($floor->floor_name); ?></label>
                            <?php else: ?>
                            <label><input type="checkbox" class="check <?php echo e($floor->floor_id); ?>" id="floor" value="<?php echo e($floor->floor_name); ?>"><?php echo e($floor->floor_name); ?></label>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <label><b>Zonals</b></label>
                            <?php $__currentLoopData = $zonalData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zonal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($zonal->zonal_name, $zonals)): ?>
                            <label><input type="checkbox" class="check <?php echo e($zonal->zonal_id); ?>" id="zonal" value="<?php echo e($zonal->zonal_name); ?>" checked><?php echo e($zonal->zonal_name); ?></label>
                            <?php else: ?>
                            <label><input type="checkbox" class="check <?php echo e($zonal->zonal_id); ?>" id="zonal" value="<?php echo e($zonal->zonal_name); ?>"><?php echo e($zonal->zonal_name); ?></label>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <label><b>Sensors</b></label>
                            <?php $__currentLoopData = $sensorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($sensor->sensor_name, $sensors)): ?>
                            <label><input type="checkbox" class="check <?php echo e($sensor->sensor_id); ?>" id="sensor" value="<?php echo e($sensor->sensor_name); ?>" checked><?php echo e($sensor->sensor_name); ?></label>
                            <?php else: ?>
                            <label><input type="checkbox" class="check <?php echo e($sensor->sensor_id); ?>" id="sensor" value="<?php echo e($sensor->sensor_name); ?>"><?php echo e($sensor->sensor_name); ?></label>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="mb-3">
                        <textarea id="selectedValues" class="form-control" name="valueNames" id="valueNames" rows="3" readonly placeholder="Selected will appear here..." style="height: 70px !important;"><?php echo e($editDisplay->floor_zonal_sensor_names); ?></textarea>
                        <input type="hidden" name="values" id="selectedval" value="<?php echo e($editDisplay->floor_zonal_sensor_ids); ?>">
                    </div>
                    <div class="mb-2 multiselect-dropdown">
                        <label for="logic_no" class="form-label">Logic to Calculate Number</label>
                        <input type="text" placeholder="Search..." class="search-box-no form-control" onclick="toggleDropdown1()" onkeyup="filterOptions1()">
                        <div class="dropdown-list-no" id="dropdown-list-no">
                            <label><input type="checkbox" class="check-no" <?php echo e(in_array('red', $logic_no) ? 'checked' : ''); ?> value="red">Red</label>
                            <label><input type="checkbox" class="check-no" <?php echo e(in_array('green', $logic_no) ? 'checked' : ''); ?> value="green">Green</label>
                            <label><input type="checkbox" class="check-no" <?php echo e(in_array('blue', $logic_no) ? 'checked' : ''); ?> value="blue">Blue</label>
                            <label><input type="checkbox" class="check-no" <?php echo e(in_array('magenta', $logic_no) ? 'checked' : ''); ?> value="magenta">Magenta</label>
                            <label><input type="checkbox" class="check-no" <?php echo e(in_array('yellow', $logic_no) ? 'checked' : ''); ?> value="yellow">Yellow</label>
                            <label><input type="checkbox" class="check-no" <?php echo e(in_array('cyan', $logic_no) ? 'checked' : ''); ?> value="cyan">Cyan</label>
                            <label><input type="checkbox" class="check-no" <?php echo e(in_array('white', $logic_no) ? 'checked' : ''); ?> value="white">White</label>
                        </div>

                    </div>
                    <div class="mb-3">
                        <textarea id="selectedValuesNo" class="form-control" name="logic_no" rows="3" readonly placeholder="Selected will appear here..."><?php echo e($editDisplay->logic_calculate_number); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="display_format" class="form-label">Display Format</label>
                        <input type="text" name="display_format" class="form-control" id="display_format" value="<?php echo e($editDisplay->display_format); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="math" class="form-label">Math Logic</label>
                        <input type="text" name="math" class="form-control" id="math" value="<?php echo e($editDisplay->math); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="coordinates" class="form-label">Coordinates</label>
                        <input type="text" name="coordinates" class="form-control" id="coordinates" value="<?php echo e($editDisplay->coordinates); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="font" class="form-label">Font</label>
                        <select class="form-select" name="font" id="font">
                            <option value="">Select Font</option>
                            <option value="F1" <?php echo e($editDisplay->font == 'F1' ? 'selected' : ''); ?>>Font 1</option>
                            <option value="F2" <?php echo e($editDisplay->font == 'F2' ? 'selected' : ''); ?>>Font 2</option>
                            <option value="F3" <?php echo e($editDisplay->font == 'F3' ? 'selected' : ''); ?>>Font 3</option>
                            <option value="F4" <?php echo e($editDisplay->font == 'F4' ? 'selected' : ''); ?>>Font 4</option>
                            <option value="F5" <?php echo e($editDisplay->font == 'F5' ? 'selected' : ''); ?>>Font 5</option>
                            <option value="F6" <?php echo e($editDisplay->font == 'F6' ? 'selected' : ''); ?>>Font 6</option>
                            <option value="F7" <?php echo e($editDisplay->font == 'F7' ? 'selected' : ''); ?>>Font 7</option>
                            <option value="F8" <?php echo e($editDisplay->font == 'F8' ? 'selected' : ''); ?>>Font 8</option>
                            <option value="F9" <?php echo e($editDisplay->font == 'F9' ? 'selected' : ''); ?>>Font 9</option>
                            <option value="F10" <?php echo e($editDisplay->font == 'F10' ? 'selected' : ''); ?>>Font 10</option>
                            <option value="F11" <?php echo e($editDisplay->font == 'F11' ? 'selected' : ''); ?>>Font 11</option>
                            <option value="F12" <?php echo e($editDisplay->font == 'F12' ? 'selected' : ''); ?>>Font 12</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="font_size" class="form-label">Font Size</label>
                        <select class="form-select" name="font_size" id="font_size">
                            <option value="">Select Font Size</option>
                            <option value="S0" <?php echo e($editDisplay->font_size == 'S0' ? 'selected' : ''); ?>>Size 0</option>
                            <option value="S1" <?php echo e($editDisplay->font_size == 'S1' ? 'selected' : ''); ?>>Size 1</option>
                            <option value="S2" <?php echo e($editDisplay->font_size == 'S2' ? 'selected' : ''); ?>>Size 2</option>
                            <option value="S3" <?php echo e($editDisplay->font_size == 'S3' ? 'selected' : ''); ?>>Size 3</option>
                            <option value="S4" <?php echo e($editDisplay->font_size == 'S4' ? 'selected' : ''); ?>>Size 4</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="color" class="form-label">Color</label>
                        <input type="text" class="form-control" name="color" placeholder="(R,G,B)" value="<?php echo e($editDisplay->color); ?>" id="color">
                            
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="goBack()">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    function goBack() {
        window.history.back(); // or use window.history.go(-1);
    }
    // Toggle the display of the dropdown list
    function toggleDropdown() {
        document.getElementById("dropdown-list").classList.toggle("active");
    }

    function toggleDropdown1() {
        document.getElementById("dropdown-list-no").classList.toggle("active");
    }

    // Filter options based on search
    function filterOptions() {
        const searchBox = document.querySelector('.search-box').value.toLowerCase();
        const labels = document.querySelectorAll('.dropdown-list label');

        labels.forEach(label => {
            const text = label.innerText.toLowerCase();
            if (text.includes(searchBox)) {
                label.style.display = "block";
            } else {
                label.style.display = "none";
            }
        });
    }

    function filterOptions1() {
        const searchBox = document.querySelector('.search-box-no').value.toLowerCase();
        const labels = document.querySelectorAll('.dropdown-list-no label');

        labels.forEach(label => {
            const text = label.innerText.toLowerCase();
            if (text.includes(searchBox)) {
                label.style.display = "block";
            } else {
                label.style.display = "none";
            }
        });
    }

    // Use event delegation for dynamically added checkboxes
    $(document).on('change', '.check', function() {
        const checkboxes = document.querySelectorAll('#dropdown-list label input[type="checkbox"]');
        let selected = [];
        let selectedIds = [];
        const floor = [];
        const zonal = [];
        const sensor = [];

        const floorIds = [];
        const zonalIds = [];
        const sensorIds = [];


        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                // selected.push(checkbox.value);
                let selectedVal = checkbox.className;
                let selectedvalue = selectedVal.substring(6);
                // console.log(selectedvalue);
                if (checkbox.id == 'floor') {
                    floor.push(checkbox.value);
                    floorIds.push(selectedvalue);
                }
                if (checkbox.id == 'zonal') {
                    zonal.push(checkbox.value);
                    zonalIds.push(selectedvalue);
                }
                if (checkbox.id == 'sensor') {
                    sensor.push(checkbox.value);
                    sensorIds.push(selectedvalue);
                }
            }
        });

        selected.push(floor);
        selected.push(zonal);
        selected.push(sensor);

        selectedIds.push(floorIds);
        selectedIds.push(zonalIds);
        selectedIds.push(sensorIds);

        selected = '{"Floor":"' + floor + '","Zonals":"' + zonal + '","Sensors":"' + sensor + '"}';
        selectedIds = '{"Floor":"' + floorIds + '","Zonals":"' + zonalIds + '","Sensors":"' + sensorIds + '"}';

        // document.getElementById("selectedValues").value = selected.join(', ');
        document.getElementById("selectedValues").value = selected;
        document.getElementById("selectedval").value = selectedIds;
    });

    $(document).on('change', '.check-no', function() {
        const checkboxes = document.querySelectorAll('#dropdown-list-no label input[type="checkbox"]');
        let selected = [];


        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                selected.push(checkbox.value);
            }
        });

        document.getElementById("selectedValuesNo").value = selected.join(',');
        // document.getElementById("selectedValues").value = selected;
        // document.getElementById("selectedval").value = selectedIds;
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\parkomate\resources\views/display/editdisplaydata.blade.php ENDPATH**/ ?>