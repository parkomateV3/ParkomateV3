
<?php $__env->startSection('content'); ?>
<style>
    label {
        margin: 0 !important;
    }
</style>
<div class="container">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-6 m-auto">
            <h4 class="text-center">Edit Detection Data</h4>
            <form action="<?php echo e(route('updatedetectiontype')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3" style="pointer-events: none;">
                        <label for="site_name" class="form-label">Site Name</label>
                        <input type="text" name="site_name" class="form-control" id="site_name" value="<?php echo e(getSitename($detectionData->site_id)); ?>">
                        <input type="hidden" name="detection_id" value="<?php echo e($detectionData->id); ?>">
                    </div>

                    <div class="mb-3" style="pointer-events: none;">
                        <label for="detection_type" class="form-label">Detection Type</label>
                        <input type="text" name="detection_type" class="form-control" id="detection_type" value="<?php echo e(getTypeName($detectionData->type_id)); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label">For Frontend Name</label>
                        <input type="text" name="name" class="form-control" id="name" value="<?php echo e($detectionData->name); ?>">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="goBack()">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    function goBack() {
        window.history.back(); // or use window.history.go(-1);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\parkomate\resources\views/detection/editdetectiontype.blade.php ENDPATH**/ ?>