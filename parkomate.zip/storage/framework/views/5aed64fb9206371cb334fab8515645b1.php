<div style="position: relative; display: inline-block;">
    <img src="<?php echo e(asset('floors/' . $floorImg)); ?>" alt="Parking Map" style="width: 1137px;height: 656px;">

    <?php $__currentLoopData = $coordinates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <button
        class="parking-btn <?php echo e($coord->status == '1' ? 'occupied' : 'available'); ?>"
        data-id="<?php echo e($coord->reservation_id); ?>"
        style="position: absolute; 
               left: <?php echo e($coord->x); ?>px; 
               top: <?php echo e($coord->y); ?>px;
               width: 20px; 
               height: 20px;
               border-radius: 50%;">
    </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<style>
    .parking-btn {
        border: 1px solid #000;
        cursor: pointer;
    }

    .available {
        background-color: green;
    }

    .occupied {
        background-color: red;
    }
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $('.parking-btn').on('click', function() {
        const button = $(this);
        const id = button.data('id');

        Swal.fire({
            title: 'Are you sure?',
            text: "You want to change status!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {

                $.ajax({
                    url: '<?php echo e(route("toggleStatus")); ?>',
                    type: 'POST',
                    data: {
                        id: id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(res) {
                        if (res.status == 1) {
                            button.removeClass('available').addClass('occupied');
                        } else {
                            button.removeClass('occupied').addClass('available');
                        }
                    }
                });
            }
        });

    });
</script><?php /**PATH F:\Laravel\parkomate\resources\views/dashboard/test.blade.php ENDPATH**/ ?>